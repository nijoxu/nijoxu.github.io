(function($) {

    $('footer').find('a').tooltip({
      placement: 'top'
    })

})(jQuery)
